/* CSCI 200: A2
 *
 * Author: Ryker Phelps
 * Resources used (Office Hours, Tutoring, Other Students, etc & in what capacity):
 *     //None
 * Description: Create an automated ATM.
 */

#include "atmFunctions.h"

int main() {
    start_atm();
    return 0;
}