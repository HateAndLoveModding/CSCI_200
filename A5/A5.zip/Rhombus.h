#ifndef RHOMBUS
#define RHOMBUS

#include "Quadrilateral.h"

class Rhombus : public Quadrilateral {
    public:
    bool validate() override;
};

#endif