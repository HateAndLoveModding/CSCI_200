#ifndef COORDINATE
#define COORDINATE

class Coordinate {
    public:
    Coordinate();
    Coordinate(float, float);
    double _x, _y;
};

#endif