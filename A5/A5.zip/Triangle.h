#ifndef TRIANGLE
#define TRIANGLE
#include "Polygon.h"

class Triangle : public Polygon {
    public:
    Triangle();
    //bool validate() override;
};

#endif