#ifndef QUADRILATERAL
#define QUADRILATERAL
#include "Polygon.h"

class Quadrilateral : public Polygon {
    public:
    Quadrilateral();
    //bool validate() override;
};

#endif