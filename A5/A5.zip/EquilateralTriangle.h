#ifndef EQUILATERAL_TRIANGLE
#define EQUILATERAL_TRIANGLE

#include "Triangle.h"

class EquilateralTriangle : public Triangle {
    public:
    bool validate() override;
};

#endif