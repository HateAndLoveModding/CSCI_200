#include "Coordinate.h"
Coordinate::Coordinate() {
    _x = 0;
    _y = 0;
}
Coordinate::Coordinate(float x, float y) {
    _x = x;
    _y = y;
}