#ifndef SCALENE_TRIANGLE
#define SCALENE_TRIANGLE

#include "Triangle.h"

class ScaleneTriangle : public Triangle {
    public:
    bool validate() override;
};

#endif